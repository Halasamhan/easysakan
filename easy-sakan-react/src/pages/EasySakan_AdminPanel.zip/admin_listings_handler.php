<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/db_connect.php';

$filter = $_GET['filter'] ?? 'all';
$action = $_GET['action'] ?? ($_POST['action'] ?? null);

if (!$action) {
    // Get listings with optional filter
    $query = "SELECT l.*, c.name as seller_name 
              FROM listings l
              LEFT JOIN customers c ON l.seller_id = c.id";
    
    if ($filter !== 'all') {
        $query .= " WHERE l.status = ?";
    }
    
    $query .= " ORDER BY l.created_at DESC";
    
    try {
        if ($filter !== 'all') {
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $filter);
            $stmt->execute();
            $result = $stmt->get_result();
        } else {
            $result = $conn->query($query);
        }
        
        $listings = [];
        while ($row = $result->fetch_assoc()) {
            $listings[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'listings' => $listings
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Server error: ' . $e->getMessage()
        ]);
    }
} elseif ($action === 'approve') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? null;

    if (!$id) {
        echo json_encode([
            'success' => false,
            'message' => 'Listing ID is required'
        ]);
        exit();
    }

    try {
        $query = "UPDATE listings SET status = 'approved' WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Listing approved successfully'
            ]);
        } else {
            throw new Exception('Failed to approve listing');
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Server error: ' . $e->getMessage()
        ]);
    }
} elseif ($action === 'reject') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? null;
    $reason = $input['reason'] ?? '';

    if (!$id) {
        echo json_encode([
            'success' => false,
            'message' => 'Listing ID is required'
        ]);
        exit();
    }

    try {
        $query = "UPDATE listings SET status = 'rejected', rejection_reason = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('si', $reason, $id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Listing rejected successfully'
            ]);
        } else {
            throw new Exception('Failed to reject listing');
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Server error: ' . $e->getMessage()
        ]);
    }
} elseif ($action === 'delete') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? null;

    if (!$id) {
        echo json_encode([
            'success' => false,
            'message' => 'Listing ID is required'
        ]);
        exit();
    }

    try {
        $query = "DELETE FROM listings WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Listing deleted successfully'
            ]);
        } else {
            throw new Exception('Failed to delete listing');
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Server error: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid action'
    ]);
}
?>
